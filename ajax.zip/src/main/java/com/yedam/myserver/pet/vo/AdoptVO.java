package com.yedam.myserver.pet.vo;

import lombok.Data;

@Data
public class AdoptVO {
    private String id;
    private String price;
}
